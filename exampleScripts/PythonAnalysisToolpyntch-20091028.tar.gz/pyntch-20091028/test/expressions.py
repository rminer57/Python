#!/usr/bin/env python

a1 = 2+3
a2 = 'a'+'b'
a3 = 2+'a' # error
a4 = 2+3.0
a5 = 2+3j
b1 = 2-3
b2 = 'a'-'b' # error
c1 = 2*3
c2 = 'a'*3
c3 = 3*'a'
c4 = [1]*3
c5 = 3*[1]
c6 = 'a'*'a' # error
d1 = 2/3
e1 = 2//3
f1 = 2%3
f2 = 'a' % 3
g1 = 2&3
h1 = 2|3
i1 = 2^3
j1 = 2>>3
j2 = 2>>3.0
k1 = 2<<3
l1 = +1
l2 = -1
l3 = ~1

print 1 == 2
print 1 != 2
print 1 <= 2
print 1 >= 2
print 1 < 2
print 1 > 2
print 1 in 2
print 1 not in 2
print 1 and 1
print 1 or 1
print not 1
