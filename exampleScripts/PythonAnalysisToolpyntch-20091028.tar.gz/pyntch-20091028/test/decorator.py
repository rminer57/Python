#!/usr/bin/env python

def baa(x):
  return x

class A:
  @classmethod
  def foo(klass):
    return

  @staticmethod
  def bar():
    return

  @baa
  def baz(self):
    return
