#!/usr/bin/env python

a = int('1')
b = str(1)
c = unicode('1')
d = list(1)
e = tuple(1)
#f = dict()
g = object()

any1 = any(1)
any2 = any([1,2,3])
all1 = all(1)
all2 = all([1,2,3])
divmod1 = divmod(1,2)
pow1 = pow(1,2)
pow2 = pow(1,2,3.0)

