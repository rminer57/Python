#!/usr/bin/env python

def plus(x,y):
  return x+y

if __name__ == '__main__':
  print plus(0,1)

