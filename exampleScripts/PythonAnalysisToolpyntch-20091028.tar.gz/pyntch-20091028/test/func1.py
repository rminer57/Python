#!/usr/bin/env python
import sys

def gcd(x,y):
  def mod(a,b):
    return a % b
  while 1:
    (y,x) = mod(x,y)
  return 

gcd(13,17)
