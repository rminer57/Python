#!/usr/bin/env python

file = 'foo'
fp = open(file, 'r')
lines = fp.readlines()
