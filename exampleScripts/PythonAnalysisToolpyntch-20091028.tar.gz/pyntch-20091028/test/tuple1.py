#!/usr/bin/env python

a = 0
b = ('',a,123)
(x,y) = b
(x,y,z) = b
c = b[100]
b[1] = 0
d = b+b
e = b*2
