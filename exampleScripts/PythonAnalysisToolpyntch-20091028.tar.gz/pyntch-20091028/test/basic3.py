
def a():
  pass

def b():
  return 1

def c():
  if 1:
    return 1

def d():
  if 1:
    return 1
  else:
    return 1

def e():
  try:
    return 1
  except:
    pass

def f():
  try:
    return 1
  except:
    return 1
