#------------------------------------------------------------------------------
#           Name: derived.py
#         Author: Kevin Harris
#  Last Modified: 04/29/05
#    Description: 
#------------------------------------------------------------------------------

from testDerived import *

class PythonDerived( Base ):
    def testMethod( self ):
        return "testMethod() of a PythonDerived object called!"
