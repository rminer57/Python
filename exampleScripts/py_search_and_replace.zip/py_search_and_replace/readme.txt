I've written the search_and_replace sample two different ways. The Python file 
named �sr.py� is setup to run like a command-line utility while the file named, 
"search_and_replace.py" is setup to run when you double click it. 

Either way, they basically do the same thing � perform search-and-replace on 
a given file.

I�ve included a simple test file named, �test.txt�, which contains the 
following three lines for you to play with.


I love cats.
Every one should own a cat!
My neighbor has a cat.


I suggest you start off by replacing all instances of the word �cat� with your 
preferred pet. Of course, if you happen to like cats, try replacing �cat� with 
something like, �kitty�.
